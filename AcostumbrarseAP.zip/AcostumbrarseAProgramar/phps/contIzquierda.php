<?php
	echo "<div class='cotenedorIzquierda'></div>";
?>