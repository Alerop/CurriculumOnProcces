<?php 
	foreach ($valores as $inside){	
		echo "<div class='coca'><nav>".$inside."</nav></div>";
	}
?>