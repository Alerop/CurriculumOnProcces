

$(function (){
	var tamañoPantallaH = window.screen.height;
	var tamañoPantallaW = window.screen.width;
	var tTH = tamañoPantallaH / 1.15;

	$("#contIzq").css({"height": tTH});
	$("#contDer").css({"height": tTH});
});
